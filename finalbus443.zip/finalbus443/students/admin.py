from django.contrib import admin
from students.models import StudentDetails
from students.models import CourseDetails
# Register your models here.

admin.site.register(StudentDetails)
admin.site.register(CourseDetails)
