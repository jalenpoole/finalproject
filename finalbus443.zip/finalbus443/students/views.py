from django.shortcuts import render
from django.http import HttpResponse
from students.models import StudentDetails
from students.models import CourseDetails
from django.db import connection
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required


# Create your views here.
@login_required
def home(request):
    return render(request, 'students/home.html')
@login_required   
def studentinfo(request):
    studentdata = StudentDetails.objects.all()
    paginator = Paginator(studentdata, 10)
    page = request.GET.get('page')
    studentminiset = paginator.get_page(page)
    return render(request,'students/details.html', {'data': studentminiset})
@login_required
def courseinfo(request):
    coursedata = CourseDetails.objects.all()
    paginator = Paginator(coursedata, 10)
    page = request.GET.get('page')
    courseminiset = paginator.get_page(page)
    return render(request, 'students/coursedetails.html', {'data': courseminiset})
@login_required
def enrollment(request):
    return render(request, 'students/enrollment.html')
@login_required
def savedata(request):
    if('cname' in request.GET):
        cname = request.GET.get('cname')
        adddata = Coursedetails(CourseName = cname)
        adddata.save()
        
        

