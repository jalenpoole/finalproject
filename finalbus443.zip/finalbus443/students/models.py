from django.db import models

# Create your models here.

class StudentDetails(models.Model):
    firstname = models.CharField(max_length=500)
    lastname = models.CharField(max_length=500)
    major = models.CharField(max_length=500)
    year = models.CharField(max_length=500)
    gpa = models.CharField(max_length=500)
    
class CourseDetails(models.Model):
    CourseId = models.IntegerField()
    CourseTitle = models.CharField(max_length=500)
    CourseName = models.CharField(max_length=500)
    CourseSectionCode = models.IntegerField()
    CourseDepartment = models.CharField(max_length=500)
    InstructorFullName = models.CharField(max_length=500)
